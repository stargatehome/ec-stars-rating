<?php
	// Éste archivo está intencionalmente en blanco para evitar navegación por directorios